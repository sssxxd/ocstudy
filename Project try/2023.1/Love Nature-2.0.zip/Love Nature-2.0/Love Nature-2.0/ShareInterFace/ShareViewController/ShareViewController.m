//
//  ShareViewController.m
//  Love Nature-2.0
//
//  Created by 孙旭东 on 2023/2/10.
//

#import "ShareViewController.h"

// 引入视图类和模型类
#import "ShareView.h"
#import "ShareModel.h"

@interface ShareViewController ()
@property (nonatomic, strong) ShareView* shareView;
@property (nonatomic, strong) ShareModel* shareModel;
@end

@implementation ShareViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self.view addSubview:self.shareView];
    [self createNavigationBarAppearance];
}

// 设置NavigationBar
- (void) createNavigationBarAppearance {
    UINavigationBarAppearance* appearance = [[UINavigationBarAppearance alloc] init];
    appearance.backgroundColor = [UIColor greenColor];
    appearance.shadowImage = [UIImage new];
    appearance.shadowColor = nil;
    
    self.title = @"分享圈";
//    self.navigationController.title = nil;
    
//    [appearance setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor whiteColor], NSFontAttributeName:[UIFont systemFontOfSize:18]}];
    
    self.navigationController.navigationBar.standardAppearance = appearance;
    self.navigationController.navigationBar.scrollEdgeAppearance = appearance;
}

#pragma mark - 懒加载
- (ShareView*) shareView {
    if (_shareView == nil) {
        self.shareView = [[ShareView alloc] initWithFrame:self.view.bounds];
    }
    return _shareView;
}


@end
