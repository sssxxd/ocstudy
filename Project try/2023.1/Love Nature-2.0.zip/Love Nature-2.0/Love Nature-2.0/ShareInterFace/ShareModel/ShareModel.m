//
//  ShareModel.m
//  Love Nature-2.0
//
//  Created by 孙旭东 on 2023/2/10.
//

#import "ShareModel.h"

@implementation ShareDataModel

+ (BOOL) propertyIsOptional:(NSString *)propertyName {
    return YES;
}

@end

@implementation ShareModel

+ (BOOL) propertyIsOptional:(NSString *)propertyName {
    return YES;
}

@end
