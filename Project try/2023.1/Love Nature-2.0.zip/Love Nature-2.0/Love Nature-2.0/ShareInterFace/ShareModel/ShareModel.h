//
//  ShareModel.h
//  Love Nature-2.0
//
//  Created by 孙旭东 on 2023/2/10.
//

#import "JSONModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface ShareDataModel : JSONModel

@property (nonatomic, copy) NSString* mainImage;
@property (nonatomic, copy) NSString* userIcon;
@property (nonatomic, copy) NSString* userName;
@property (nonatomic, copy) NSString* title;

@end

@interface ShareModel : JSONModel

@property (nonatomic, strong) ShareDataModel* data;

@end

NS_ASSUME_NONNULL_END
