//
//  ShareViewCollectionViewCell.m
//  Love Nature-2.0
//
//  Created by 孙旭东 on 2023/2/12.
//

#import "ShareViewCollectionViewCell.h"

// 引入模型类
#import "ShareModel.h"

// 引入第三方库
#import "Masonry.h"

@interface ShareViewCollectionViewCell ()

@property (nonatomic, strong) UILabel* titleLabel;
@property (nonatomic, strong) UIImageView* userIconImageView;
@property (nonatomic, strong) UILabel* userNameLabel;
@property (nonatomic, strong) UIImageView* mainImageView;

@end

@implementation ShareViewCollectionViewCell {
    CGFloat _iconWidth;
}

- (instancetype) initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        self.contentView.backgroundColor = [UIColor whiteColor];
        
        _iconWidth = frame.size.width / 10;
    }
    return self;
}

- (void) layoutIfNeeded {
    [super layoutIfNeeded];
    [self.contentView addSubview:self.titleLabel];
    [self.contentView addSubview:self.userNameLabel];
    [self.contentView addSubview:self.mainImageView];
    [self.contentView addSubview:self.userIconImageView];
    
    _mainImageView.layer.cornerRadius = 8;
    _mainImageView.layer.masksToBounds = YES;
    
    _userIconImageView.layer.cornerRadius = _iconWidth / 2;
    _userIconImageView.layer.masksToBounds = YES;
    
    _mainImageView.image = [UIImage imageNamed:_shareDataModel.mainImage];
    _userIconImageView.image = [UIImage imageNamed:_shareDataModel.userIcon];
    _userNameLabel.text = _shareDataModel.userName;
    _titleLabel.text = _shareDataModel.title;
    
    [self layoutOfMasonry];
}

// 设置约束
- (void) layoutOfMasonry {

    [_mainImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_offset(0);
        make.width.equalTo(self.contentView);
        make.bottom.mas_offset(-50);
    }];

    [_titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(_mainImageView.mas_bottom).mas_offset(5);
        make.bottom.mas_offset(-25);
        make.left.mas_offset(5);
        make.right.mas_offset(-5);
    }];

    [_userIconImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(_titleLabel.mas_bottom).mas_offset(5);
        make.left.mas_offset(5);
        make.size.mas_offset(_iconWidth);
    }];

    [_userNameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_userIconImageView);
        make.left.mas_equalTo(_userIconImageView.mas_right).mas_offset(5);
        make.height.mas_offset(15);
        make.right.mas_offset(-5);
    }];
    
}

#pragma mark - 懒加载
- (UILabel*) titleLabel {
    if (_titleLabel == nil) {
        self.titleLabel = [[UILabel alloc] init];
        _titleLabel.textColor = [UIColor blackColor];
        _titleLabel.font = [UIFont systemFontOfSize:15];
    }
    return _titleLabel;
}

- (UIImageView*) userIconImageView {
    if (_userIconImageView == nil) {
        self.userIconImageView = [[UIImageView alloc] init];
    }
    return _userIconImageView;
}

- (UIImageView*) mainImageView {
    if (_mainImageView == nil) {
        self.mainImageView = [[UIImageView alloc] init];
    }
    return _mainImageView;
}

- (UILabel*) userNameLabel {
    if (_userNameLabel == nil) {
        self.userNameLabel = [[UILabel alloc] init];
        _userNameLabel.textColor = [UIColor grayColor];
        _userNameLabel.font = [UIFont systemFontOfSize:12];
    }
    return _userNameLabel;
}

@end
