//
//  ShareView.m
//  Love Nature-2.0
//
//  Created by 孙旭东 on 2023/2/10.
//

#import "ShareView.h"

// 引入layout
#import "ShareViewCollectionViewFlowLayout.h"

// 引入cell
#import "ShareViewCollectionViewCell.h"
// cell名称
static NSString *const cellName = @"ShareViewCollectionViewCell";

// 引入模型类
#import "ShareModel.h"

@interface ShareView ()

@property (nonatomic, strong) UICollectionView* collectionView;

@end

@implementation ShareView

- (instancetype) initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        
        self.shareDataModelArray = [[NSMutableArray alloc] init];
        
        for (int i = 0; i < 10; i++) {
            ShareDataModel* data = [[ShareDataModel alloc] init];
            data.userName = @"铲屎官";
            data.title = @"狸花猫，猫界中的战斗猫！";
            data.mainImage = @"lihuamao.jpg";
            data.userIcon = @"userIcon.jpeg";
            
            [_shareDataModelArray addObject:data];
        }
        
        [self addSubview:self.collectionView];
    }
    return self;
}

- (NSInteger) numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 1;
}

- (NSInteger) collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return 10;
}

- (UICollectionViewCell*) collectionView:(UICollectionView*)collectionView cellForItemAtIndexPath:(nonnull NSIndexPath *)indexPath {
    ShareViewCollectionViewCell* cell = [self.collectionView dequeueReusableCellWithReuseIdentifier:cellName forIndexPath:indexPath];
    
    cell.shareDataModel = _shareDataModelArray[indexPath.row];
    
    [cell layoutIfNeeded];
    
    return cell;
}

#pragma mark - 懒加载
- (UICollectionView*) collectionView {
    if (_collectionView == nil) {
        ShareViewCollectionViewFlowLayout* flowLayout = [[ShareViewCollectionViewFlowLayout alloc] init];
        flowLayout.scrollDirection = UICollectionViewScrollDirectionVertical;
        flowLayout.itemCount = 10;
        flowLayout.sectionInset = UIEdgeInsetsMake(0, 10, 0, 10);
        
        self.collectionView = [[UICollectionView alloc] initWithFrame:self.bounds collectionViewLayout:flowLayout];
        _collectionView.delegate = self;
        _collectionView.dataSource = self;
        
        [_collectionView registerClass:[ShareViewCollectionViewCell class] forCellWithReuseIdentifier:cellName];
    }
    return _collectionView;
}

@end
