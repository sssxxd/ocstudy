//
//  ShareViewCollectionViewFlowLayout.h
//  Love Nature-2.0
//
//  Created by 孙旭东 on 2023/2/12.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ShareViewCollectionViewFlowLayout : UICollectionViewFlowLayout

@property (nonatomic, assign) NSUInteger itemCount;

@end

NS_ASSUME_NONNULL_END
