//
//  ShareViewCollectionViewFlowLayout.m
//  Love Nature-2.0
//
//  Created by 孙旭东 on 2023/2/12.
//

#import "ShareViewCollectionViewFlowLayout.h"

@interface ShareViewCollectionViewFlowLayout ()

@property (nonatomic, strong) NSMutableArray* attributeArray;

@end

@implementation ShareViewCollectionViewFlowLayout

- (void) prepareLayout {
    [super prepareLayout];
    
    self.attributeArray = [[NSMutableArray alloc] init];
    
    CGFloat width = ([UIScreen mainScreen].bounds.size.width - self.minimumInteritemSpacing - self.sectionInset.left - self.sectionInset.right) / 2;
    
    CGFloat colHight[2] = {0};
    
    for (NSUInteger i = 0; i < _itemCount; i++) {
        NSIndexPath* index = [NSIndexPath indexPathForItem:i inSection:0];
        
        UICollectionViewLayoutAttributes* attributes = [UICollectionViewLayoutAttributes layoutAttributesForCellWithIndexPath:index];
        
        CGFloat hight = arc4random()%61 + 150;
        
        int flag = 0;
        if (colHight[0] < colHight[1]) {
            colHight[0] = colHight[0] + hight + self.minimumLineSpacing;
            flag = 0;
        } else {
            colHight[1] = colHight[1] + hight + self.minimumLineSpacing;
            flag = 1;
        }
        
        attributes.frame = CGRectMake(self.sectionInset.left + (self.minimumInteritemSpacing + width) * flag, colHight[flag] - hight - self.minimumLineSpacing, width, hight);
        
        [_attributeArray addObject:attributes];
    }
    
    if (colHight[0] > colHight[1]) {
        self.itemSize = CGSizeMake(width, ((colHight[0] - self.sectionInset.top) * 2 / self.itemCount - self.minimumLineSpacing));
    } else {
        self.itemSize = CGSizeMake(width, ((colHight[1] - self.sectionInset.top) * 2 / self.itemCount - self.minimumLineSpacing));
    }
}

- (nullable NSArray<__kindof UICollectionViewLayoutAttributes *> *) layoutAttributesForElementsInRect:(CGRect)rect {
    return _attributeArray;
}

@end
