//
//  ShareView.h
//  Love Nature-2.0
//
//  Created by 孙旭东 on 2023/2/10.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@class ShareDataModel;

@interface ShareView : UIView
<UICollectionViewDelegate, UICollectionViewDataSource>

@property (nonatomic, strong) NSMutableArray<ShareDataModel*>* shareDataModelArray;

@end

NS_ASSUME_NONNULL_END
