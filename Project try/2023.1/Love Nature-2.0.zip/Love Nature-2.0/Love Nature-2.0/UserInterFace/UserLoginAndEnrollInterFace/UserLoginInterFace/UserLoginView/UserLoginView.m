//
//  UserLoginView.m
//  Love Nature-2.0
//
//  Created by 孙旭东 on 2023/2/1.
//

#import "UserLoginView.h"

// 引入第三方库
#import "Masonry.h"

// 预定义屏幕宽
#define KSCREEN_WIDTH [UIScreen mainScreen].bounds.size.width

// 定义全局变量
    // 用于记录重新获取验证码所需时间
static NSInteger timeOfPressgetVerCodeButton = 60;
    // 记录现在使用的登陆状态
static UserLoginViewLoginMethod userLoginViewLoginMethod = UserLoginViewLoginMethodPassword;
    // 通知名称
NSString *const loginMessageOfGetVerCode = @"messageOfGetVerCode";
NSString *const messageOfOpenEnrollViewController = @"messageOfOpenEnrollViewController";

@interface UserLoginView ()

// 装饰视图
@property (nonatomic, strong) UIView* topLineView;
@property (nonatomic, strong) UIView* shadowView;

// 登陆方式切换密码
@property (nonatomic, strong) UIButton* passwordLoginButton;
@property (nonatomic, strong) UIButton* verCodeLoginButton;

// 登陆方式背景视图
    // 滚动视图
@property (nonatomic, strong) UIScrollView* backScrollView;
    // 容器视图
@property (nonatomic, strong) UIView* containView;
@property (nonatomic, strong) UIView* passwordContainView;
@property (nonatomic, strong) UIView* verCodeContainView;

// 密码登陆
@property (nonatomic, strong) UILabel* passwordEmailLabel;
@property (nonatomic, strong) UILabel* passwordLabel;
@property (nonatomic, strong) UITextField* passwordEmailTextField;
@property (nonatomic, strong) UITextField* passwordTextField;

// 验证码登陆
@property (nonatomic, strong) UILabel* verCodeEmailLabel;
@property (nonatomic, strong) UILabel* verCodeLabel;
@property (nonatomic, strong) UITextField* verCodeEmailTextField;
@property (nonatomic, strong) UITextField* verCodeTextField;
@property (nonatomic, strong) UIButton* verCodeGetButton;
@property (nonatomic, strong) NSTimer* getVerCodeTimer;

@end



@implementation UserLoginView

- (instancetype) initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        
        self.backgroundColor = [UIColor whiteColor];
        
        [self initDecorationViewAndContainView];
        [self initKeyUIOfLoginWithPassword];
        [self initKeyUIOfLoginWithVerCode];
        [self initLoginAndEnrollButton];
    }
    return self;
}

- (void) dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

// 放下键盘
- (void) touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [_passwordTextField resignFirstResponder];
    [_passwordEmailTextField resignFirstResponder];
    [_verCodeTextField resignFirstResponder];
    [_verCodeEmailTextField resignFirstResponder];
}

// 初始化装饰视图和容器视图
- (void) initDecorationViewAndContainView {
    self.topLineView = [[UIView alloc] init];
    _topLineView.backgroundColor = [UIColor grayColor];
    [self addSubview:_topLineView];
    
    [_topLineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_offset(90);
        make.left.mas_offset(0);
        make.right.mas_offset(0);
        make.height.mas_offset(3);
    }];
    
    self.passwordLoginButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [_passwordLoginButton setTitle:@"密码登陆" forState:UIControlStateNormal];
    [_passwordLoginButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self addSubview:_passwordLoginButton];
    
    [_passwordLoginButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(_topLineView.mas_bottom);
        make.left.mas_offset(0);
        make.width.mas_offset(KSCREEN_WIDTH/2);
        make.height.mas_offset(60);
    }];
    
    [_passwordLoginButton addTarget:self action:@selector(pressPasswordLoginButton) forControlEvents:UIControlEventTouchUpInside];
    
    self.verCodeLoginButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [_verCodeLoginButton setTitle:@"验证码登陆" forState:UIControlStateNormal];
    [_verCodeLoginButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self addSubview:_verCodeLoginButton];
    
    [_verCodeLoginButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(_topLineView.mas_bottom);
        make.left.mas_equalTo(_passwordLoginButton.mas_right);
        make.right.mas_offset(0);
        make.height.mas_offset(60);
    }];
    
    [_verCodeLoginButton addTarget:self action:@selector(pressVerCodeLoginButton) forControlEvents:UIControlEventTouchUpInside];
    
    self.shadowView = [[UIView alloc] init];
    _shadowView.backgroundColor = [UIColor grayColor];
    _shadowView.alpha = 0.6;
    [self addSubview:_shadowView];
    
    [_shadowView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(_passwordLoginButton);
        make.left.mas_equalTo(_passwordLoginButton);
        make.size.mas_equalTo(_passwordLoginButton);
    }];
    
    self.backScrollView = [[UIScrollView alloc] init];
    _backScrollView.pagingEnabled = YES;
    _backScrollView.userInteractionEnabled = YES;
    _backScrollView.showsHorizontalScrollIndicator = NO;
    _backScrollView.scrollEnabled = NO;
    [self addSubview:_backScrollView];
    
    [_backScrollView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(_passwordLoginButton.mas_bottom);
        make.left.mas_offset(0);
        make.right.mas_offset(0);
        make.height.mas_offset(160);
    }];
    
    
    self.containView = [[UIView alloc] init];
    _containView.userInteractionEnabled = YES;
    [_backScrollView addSubview:_containView];
    
    [_containView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(_backScrollView);
        make.height.equalTo(_backScrollView);
    }];
    
    self.passwordContainView = [[UIView alloc] init];
    _passwordContainView.userInteractionEnabled = YES;
    [_containView addSubview:_passwordContainView];
    
    [_passwordContainView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_offset(0);
        make.left.mas_offset(0);
        make.width.mas_offset(KSCREEN_WIDTH);
        make.bottom.mas_offset(0);
    }];
    
    self.verCodeContainView = [[UIView alloc] init];
    _passwordContainView.userInteractionEnabled = YES;
    [_containView addSubview:_verCodeContainView];
    
    [_verCodeContainView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_offset(0);
        make.left.mas_equalTo(_passwordContainView.mas_right);
        make.width.mas_offset(KSCREEN_WIDTH);
        make.bottom.mas_offset(0);
    }];
    
    [_containView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(_verCodeContainView.mas_right);
    }];
}

// 初始化关键UI
    // 初始化关于密码登陆的UI
- (void) initKeyUIOfLoginWithPassword {
    self.passwordEmailLabel = [[UILabel alloc] init];
    _passwordEmailLabel.text = @"邮箱";
    _passwordEmailLabel.font = [UIFont systemFontOfSize:18];
    [_passwordContainView addSubview:_passwordEmailLabel];
    
    [_passwordEmailLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_offset(60);
        make.left.mas_offset(20);
        make.width.mas_offset(40);
    }];
    
    self.passwordLabel = [[UILabel alloc] init];
    _passwordLabel.text = @"密码";
    _passwordLabel.font = [UIFont systemFontOfSize:18];
    [_passwordContainView addSubview:_passwordLabel];
    
    [_passwordLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(_passwordEmailLabel.mas_bottom).mas_offset(30);
        make.left.mas_offset(20);
        make.width.mas_offset(40);
    }];
    
    self.passwordEmailTextField = [[UITextField alloc] init];
    _passwordEmailTextField.placeholder = @"请输入邮箱";
    _passwordEmailTextField.keyboardType = UIKeyboardTypeDefault;
    _passwordEmailTextField.autocapitalizationType = UITextAutocapitalizationTypeNone;
    [_passwordContainView addSubview:_passwordEmailTextField];
    
    [_passwordEmailTextField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(_passwordEmailLabel).mas_offset(-7);
        make.bottom.mas_equalTo(_passwordEmailLabel).mas_offset(7);
        make.right.mas_offset(-20);
        make.left.mas_equalTo(_passwordEmailLabel.mas_right).mas_offset(10);
    }];
    
    _passwordEmailTextField.layer.borderWidth = 1;
    _passwordEmailTextField.layer.borderColor = [UIColor grayColor].CGColor;
    _passwordEmailTextField.userInteractionEnabled = YES;
    
    self.passwordTextField = [[UITextField alloc] init];
    _passwordTextField.placeholder = @"请输入密码，6到18位字母或数字";
    _passwordTextField.secureTextEntry = YES;
    [_passwordContainView addSubview:_passwordTextField];
    
    [_passwordTextField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(_passwordLabel).mas_offset(-7);
        make.bottom.mas_equalTo(_passwordLabel).mas_offset(7);
        make.right.mas_offset(-20);
        make.left.mas_equalTo(_passwordLabel.mas_right).mas_offset(10);
    }];
    
    _passwordTextField.layer.borderWidth = 1;
    _passwordTextField.layer.borderColor = [UIColor grayColor].CGColor;
    _passwordTextField.userInteractionEnabled = YES;
}

    // 关于验证码登陆的UI
- (void) initKeyUIOfLoginWithVerCode {
    self.verCodeEmailLabel = [[UILabel alloc] init];
    _verCodeEmailLabel.text = @"邮箱";
    _verCodeEmailLabel.font = [UIFont systemFontOfSize:18];
    [_verCodeContainView addSubview:_verCodeEmailLabel];
    
    [_verCodeEmailLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_offset(60);
        make.left.mas_offset(20);
        make.width.mas_offset(40);
    }];
    
    self.verCodeLabel = [[UILabel alloc] init];
    _verCodeLabel.text = @"验证码";
    _verCodeLabel.font = [UIFont systemFontOfSize:18];
    [_verCodeContainView addSubview:_verCodeLabel];
    
    [_verCodeLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(_verCodeEmailLabel.mas_bottom).mas_offset(30);
        make.right.equalTo(_verCodeEmailLabel);
    }];
    
    self.verCodeEmailTextField = [[UITextField alloc] init];
    _verCodeEmailTextField.placeholder = @"请输入邮箱";
    _verCodeEmailTextField.keyboardType = UIKeyboardTypeDefault;
    _verCodeEmailTextField.autocapitalizationType = UITextAutocapitalizationTypeNone;
    [_verCodeContainView addSubview:_verCodeEmailTextField];
    
    [_verCodeEmailTextField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(_verCodeEmailLabel).mas_offset(-7);
        make.bottom.mas_equalTo(_verCodeEmailLabel).mas_offset(7);
        make.right.mas_offset(-20);
        make.left.mas_equalTo(_verCodeEmailLabel.mas_right).mas_offset(10);
    }];
    
    _verCodeEmailTextField.layer.borderWidth = 1;
    _verCodeEmailTextField.layer.borderColor = [UIColor grayColor].CGColor;
    
    self.verCodeTextField = [[UITextField alloc] init];
    _verCodeTextField.placeholder = @"验证码";
    _verCodeTextField.autocapitalizationType = UITextAutocapitalizationTypeNone;
    [_verCodeContainView addSubview:_verCodeTextField];
    
    [_verCodeTextField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(_verCodeLabel).mas_offset(-7);
        make.bottom.mas_equalTo(_verCodeLabel).mas_offset(7);
        make.right.mas_offset(-160);
        make.left.mas_equalTo(_verCodeLabel.mas_right).mas_offset(10);
    }];
    
    _verCodeTextField.layer.borderWidth = 1;
    _verCodeTextField.layer.borderColor = [UIColor grayColor].CGColor;
    
    self.verCodeGetButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [_verCodeGetButton setTitle:@"获取验证码" forState:UIControlStateNormal];
    [_verCodeGetButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_verCodeContainView addSubview:_verCodeGetButton];
    
    [_verCodeGetButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_verCodeTextField);
        make.bottom.equalTo(_verCodeTextField);
        make.left.mas_equalTo(_verCodeTextField.mas_right).mas_offset(10);
        make.right.mas_offset(-20);
    }];
    
    [_verCodeGetButton addTarget:self action:@selector(pressVerCodeGetButton:) forControlEvents:UIControlEventTouchUpInside];
}

#pragma mark - 按钮及其事件
// 获取验证码
- (void) pressVerCodeGetButton:(UIButton*)sender {
    sender.userInteractionEnabled = NO;
    [sender setTitle:[NSString stringWithFormat:@"%ld s后", timeOfPressgetVerCodeButton] forState:UIControlStateNormal];
    [self createGetVerCodeTimer];
    self.emailString = _verCodeEmailTextField.text;
    
    [[NSNotificationCenter defaultCenter] postNotificationName:loginMessageOfGetVerCode object:nil];
}

// 获取验证码计时器
- (void) createGetVerCodeTimer {
    self.getVerCodeTimer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(getVerCodeTimerAction) userInfo:nil repeats:YES];
}

- (void) getVerCodeTimerAction {
    if (timeOfPressgetVerCodeButton != 0) {
        timeOfPressgetVerCodeButton--;
        
        [_verCodeGetButton setTitle:[NSString stringWithFormat:@"%ld s后", timeOfPressgetVerCodeButton] forState:UIControlStateNormal];
    } else {
        [_verCodeGetButton setTitle:@"重新获取" forState:UIControlStateNormal];
        _verCodeGetButton.userInteractionEnabled = YES;
        
        [_getVerCodeTimer invalidate];
        self.getVerCodeTimer = nil;
        
        timeOfPressgetVerCodeButton = 60;
    }
}

// 切换登录方式
- (void) pressPasswordLoginButton {
    userLoginViewLoginMethod = UserLoginViewLoginMethodPassword;
    
    _backScrollView.contentOffset = CGPointMake(0, 0);
    
    [_shadowView mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_passwordLoginButton);
        make.left.equalTo(_passwordLoginButton);
        make.size.equalTo(_passwordLoginButton);
    }];
}

- (void) pressVerCodeLoginButton {
    userLoginViewLoginMethod = UserLoginViewLoginMethodVerCode;
    
    _backScrollView.contentOffset = CGPointMake(KSCREEN_WIDTH, 0);
    
    [_shadowView mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_verCodeLoginButton);
        make.left.equalTo(_verCodeLoginButton);
        make.size.equalTo(_verCodeLoginButton);
    }];
}

// 注册和登陆按钮
- (void) initLoginAndEnrollButton {
    self.enrollButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [_enrollButton setTitle:@"注册" forState:UIControlStateNormal];
    [_enrollButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self addSubview:_enrollButton];
    
    [_enrollButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(_backScrollView.mas_bottom);
        make.right.mas_offset(-20);
        make.width.mas_offset(40);
    }];
    
    [_enrollButton addTarget:self action:@selector(pressEnrollButton) forControlEvents:UIControlEventTouchUpInside];
    
    self.loginButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [_loginButton setTitle:@"登陆" forState:UIControlStateNormal];
    [_loginButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self addSubview:_loginButton];
    
    [_loginButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(_backScrollView.mas_bottom).mas_offset(60);
        make.centerX.mas_offset(0);
        make.width.mas_offset(90);
        make.height.mas_offset(50);
    }];
    
    _loginButton.layer.borderWidth = 1;
    _loginButton.layer.borderColor = [UIColor blackColor].CGColor;
    _loginButton.layer.cornerRadius = 5;
    _loginButton.layer.masksToBounds = YES;
}

// 打开注册页面
- (void) pressEnrollButton {
    [[NSNotificationCenter defaultCenter] postNotificationName:messageOfOpenEnrollViewController object:nil];
}

// 传输登陆所需信息
- (void) loginNeedInfoCompletionHandler:(LoginNeedInfoCompletionHandler)handler {
    switch (userLoginViewLoginMethod) {
        case UserLoginViewLoginMethodPassword:
            self.emailString = _passwordEmailTextField.text;
            self.passwordOrCodeString = _passwordTextField.text;
            
            handler(_emailString, _passwordOrCodeString, userLoginViewLoginMethod);
            break;
        case UserLoginViewLoginMethodVerCode:
            self.emailString = _verCodeEmailTextField.text;
            self.passwordOrCodeString = _verCodeTextField.text;
            
            handler(_emailString, _passwordOrCodeString, userLoginViewLoginMethod);
            break;
    }
}
@end
