//
//  UserLoginViewController.h
//  Love Nature-2.0
//
//  Created by 孙旭东 on 2023/2/1.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

// 设置全局变量
    // 通知名称
extern NSString *const UserLoginViewControllerLoginSucceed;

@interface UserLoginViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
