//
//  UserEnrollView.m
//  Love Nature-2.0
//
//  Created by 孙旭东 on 2023/2/3.
//

#import "UserEnrollView.h"

// 引入第三方库
#import "Masonry.h"

// 设置全局变量
    // 记录获取验证码剩余时间
static NSInteger timeOfPressgetVerCodeButton = 60;
    // 通知名称
NSString *const enrollMessageOfGetVerCode = @"enrollMessageOfGetVerCode";


@interface UserEnrollView ()

// label
@property (nonatomic, strong) UILabel* emailLabel;
@property (nonatomic, strong) UILabel* verCodeLabel;
@property (nonatomic, strong) UILabel* passwordLabel;
@property (nonatomic, strong) UILabel* rePasswordLabel;

// textField
@property (nonatomic, strong) UITextField* emailTextField;
@property (nonatomic, strong) UITextField* verCodeTextField;
@property (nonatomic, strong) UITextField* passwordTextField;
@property (nonatomic, strong) UITextField* rePasswordTextField;

// button
@property (nonatomic, strong) UIButton* getVerCodeButton;

// 计时器
@property (nonatomic, strong) NSTimer* getVerCodeTimer;
@end


@implementation UserEnrollView

// 重写init
- (instancetype) initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        
        self.backgroundColor = [UIColor whiteColor];
        
        [self initUILable];
        [self initUITextField];
        [self initUIButton];
    }
    return self;
}

// 放下键盘
- (void) touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [_emailTextField resignFirstResponder];
    [_verCodeTextField resignFirstResponder];
    [_passwordTextField resignFirstResponder];
    [_rePasswordTextField resignFirstResponder];
}

#pragma mark - 初始化UI视图
// 初始化label
- (void) initUILable {
    self.emailLabel = [[UILabel alloc] init];
    _emailLabel.text = @"邮箱";
    _emailLabel.font = [UIFont systemFontOfSize:18];
    [self addSubview:_emailLabel];
    
    [_emailLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_offset(120);
        make.left.mas_offset(20);
        make.width.mas_offset(40);
    }];
    
    self.verCodeLabel = [[UILabel alloc] init];
    _verCodeLabel.text = @"验证码";
    _verCodeLabel.font = [UIFont systemFontOfSize:18];
    [self addSubview:_verCodeLabel];
    
    [_verCodeLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(_emailLabel.mas_bottom).mas_offset(30);
        make.right.equalTo(_emailLabel);
    }];
    
    self.passwordLabel = [[UILabel alloc] init];
    _passwordLabel.text = @"密码";
    _passwordLabel.font = [UIFont systemFontOfSize:18];
    [self addSubview:_passwordLabel];
    
    [_passwordLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(_verCodeLabel.mas_bottom).mas_offset(30);
        make.right.equalTo(_emailLabel);
    }];
    
    self.rePasswordLabel = [[UILabel alloc] init];
    _rePasswordLabel.text = @"重复密码";
    _rePasswordLabel.font = [UIFont systemFontOfSize:14];
    [self addSubview:_rePasswordLabel];
    
    [_rePasswordLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(_passwordLabel.mas_bottom).mas_offset(30);
        make.right.equalTo(_emailLabel);
    }];
}

// 初始化UItextField
- (void) initUITextField {
    self.emailTextField = [[UITextField alloc] init];
    _emailTextField.placeholder = @"请输入邮箱";
    _emailTextField.keyboardType = UIKeyboardTypeDefault;
    _emailTextField.autocapitalizationType = UITextAutocapitalizationTypeNone;
    [self addSubview:_emailTextField];
    
    [_emailTextField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(_emailLabel).mas_offset(-7);
        make.bottom.mas_equalTo(_emailLabel).mas_offset(7);
        make.left.mas_equalTo(_emailLabel.mas_right).mas_offset(10);
        make.right.mas_offset(-20);
    }];
    
    _emailTextField.layer.borderWidth = 1;
    _emailTextField.layer.borderColor = [UIColor blackColor].CGColor;
    
    self.verCodeTextField = [[UITextField alloc] init];
    _verCodeTextField.placeholder = @"验证码";
    _verCodeTextField.keyboardType = UIKeyboardTypeDefault;
    _verCodeTextField.autocapitalizationType = UITextAutocapitalizationTypeNone;
    [self addSubview:_verCodeTextField];
    
    [_verCodeTextField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(_verCodeLabel).mas_offset(-7);
        make.bottom.mas_equalTo(_verCodeLabel).mas_offset(7);
        make.right.mas_offset(-160);
        make.left.mas_equalTo(_verCodeLabel.mas_right).mas_offset(10);
    }];
    
    _verCodeTextField.layer.borderWidth = 1;
    _verCodeTextField.layer.borderColor = [UIColor blackColor].CGColor;
    
    _passwordTextField = [[UITextField alloc] init];
    _passwordTextField.placeholder = @"请输入密码，6到18位字母或数字";
    _passwordTextField.keyboardType = UIKeyboardTypeDefault;
    _passwordTextField.autocapitalizationType = UITextAutocapitalizationTypeNone;
    [self addSubview:_passwordTextField];
    
    [_passwordTextField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(_passwordLabel).mas_offset(-7);
        make.bottom.mas_equalTo(_passwordLabel).mas_offset(7);
        make.right.mas_offset(-20);
        make.left.mas_equalTo(_passwordLabel.mas_right).mas_offset(10);
    }];
    
    _passwordTextField.layer.borderWidth = 1;
    _passwordTextField.layer.borderColor = [UIColor blackColor].CGColor;
    
    _rePasswordTextField = [[UITextField alloc] init];
    _rePasswordTextField.placeholder = @"请输入密码，6到18位字母或数字";
    _rePasswordTextField.keyboardType = UIKeyboardTypeDefault;
    _rePasswordTextField.autocapitalizationType = UITextAutocapitalizationTypeNone;
    [self addSubview:_rePasswordTextField];
    
    [_rePasswordTextField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(_rePasswordLabel).mas_offset(-7);
        make.bottom.mas_equalTo(_rePasswordLabel).mas_offset(7);
        make.right.mas_offset(-20);
        make.left.mas_equalTo(_rePasswordLabel.mas_right).mas_offset(10);
    }];
    
    _rePasswordTextField.layer.borderWidth = 1;
    _rePasswordTextField.layer.borderColor = [UIColor blackColor].CGColor;
}

// 初始化Button
- (void) initUIButton {
    self.getVerCodeButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [_getVerCodeButton setTitle:@"获取验证码" forState:UIControlStateNormal];
    [_getVerCodeButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self addSubview:_getVerCodeButton];
    
    [_getVerCodeButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_verCodeTextField);
        make.bottom.equalTo(_verCodeTextField);
        make.left.mas_equalTo(_verCodeTextField.mas_right).mas_offset(10);
        make.right.mas_offset(-20);
    }];
    
    [_getVerCodeButton addTarget:self action:@selector(pressGetVerCodeButton:) forControlEvents:UIControlEventTouchUpInside];
    
    self.enrollButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [_enrollButton setTitle:@"注册" forState:UIControlStateNormal];
    [_enrollButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self addSubview:_enrollButton];
    
    [_enrollButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(_rePasswordTextField).mas_offset(60);
        make.centerX.mas_offset(0);
        make.width.mas_offset(90);
        make.height.mas_offset(50);
    }];
    
    _enrollButton.layer.borderWidth = 1;
    _enrollButton.layer.borderColor = [UIColor blackColor].CGColor;
    _enrollButton.layer.cornerRadius = 5;
    _enrollButton.layer.masksToBounds = YES;
}

// 获取验证码
- (void) pressGetVerCodeButton:(UIButton*)sender {
    sender.userInteractionEnabled = NO;
    [sender setTitle:[NSString stringWithFormat:@"%ld s后", timeOfPressgetVerCodeButton] forState:UIControlStateNormal];
    [self createGetVerCodeTimer];
    self.emailString = _emailTextField.text;
    
    [[NSNotificationCenter defaultCenter] postNotificationName:enrollMessageOfGetVerCode object:nil];
}

// 获取验证码计时器
- (void) createGetVerCodeTimer {
    self.getVerCodeTimer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(getVerCodeTimerAction) userInfo:nil repeats:YES];
}

- (void) getVerCodeTimerAction {
    if (timeOfPressgetVerCodeButton != 0) {
        timeOfPressgetVerCodeButton--;
        
        [_getVerCodeButton setTitle:[NSString stringWithFormat:@"%ld s后", timeOfPressgetVerCodeButton] forState:UIControlStateNormal];
    } else {
        [_getVerCodeButton setTitle:@"重新获取" forState:UIControlStateNormal];
        _getVerCodeButton.userInteractionEnabled = YES;
        
        [_getVerCodeTimer invalidate];
        self.getVerCodeTimer = nil;
        
        timeOfPressgetVerCodeButton = 60;
    }
}

// 注册方法，使用块传值给viewController
- (void) enrollWithEnrollNeedInfoCompletionHandler:(EnrollNeedInfoCompletionHandler)enrollNeedInfoCompletionHandler {
    
    self.emailString = _emailTextField.text;
    self.codeString = _verCodeTextField.text;
    self.passwordString = _passwordTextField.text;
    
    if ([_passwordString isEqualToString:_rePasswordTextField.text]) {
        enrollNeedInfoCompletionHandler(_emailString, _passwordString, _codeString);
    }
}

@end
