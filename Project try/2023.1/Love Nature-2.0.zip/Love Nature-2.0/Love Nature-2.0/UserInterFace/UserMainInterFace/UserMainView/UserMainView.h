//
//  UserMainView.h
//  Love Nature-2.0
//
//  Created by 孙旭东 on 2023/1/31.
//

#import <UIKit/UIKit.h>

@class  UserInfoDataModel;
NS_ASSUME_NONNULL_BEGIN

// 设置全局变量
extern NSString *const messageOfToLogin;
extern NSString *const messageOfExitLogin;

@interface UserMainView : UIView
<UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) UserInfoDataModel* userInfoDataModel;

- (void) reloadTableView;
@end

NS_ASSUME_NONNULL_END
