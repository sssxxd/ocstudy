//
//  UserMainView.m
//  Love Nature-2.0
//
//  Created by 孙旭东 on 2023/1/31.
//

#import "UserMainView.h"

// 引入Cell
#import "UserMainViewCells/UserMainViewUserInfoTableViewCell.h"

// 引入Model
#import "UserMainModel.h"

// 预定义屏幕高和宽
#define KSCREEN_HEIGHT [UIScreen mainScreen].bounds.size.height
#define KSCREEN_WIDTH [UIScreen mainScreen].bounds.size.width

// 定义全局变量
NSString *const messageOfToLogin = @"messageOfToLogin";
NSString *const messageOfExitLogin = @"messageOfExitLogin";

// 类别
@interface UserMainView ()
@property (nonatomic, strong) UITableView* tableView;
@end

// 实现
@implementation UserMainView

// init方法
- (instancetype) initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self initTableView];
    }
    return self;
}

- (void) dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

// 初始化UItableView
- (void) initTableView {
    self.tableView = [[UITableView alloc] initWithFrame:self.bounds style:UITableViewStyleGrouped];
    
//    _tableView.backgroundColor = [UIColor whiteColor];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.userInteractionEnabled = YES;
    
    [self addSubview:_tableView];
}

- (CGFloat) tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        return KSCREEN_HEIGHT / 4;
    }
    return 60;
}

- (NSInteger) numberOfSectionsInTableView:(UITableView *)tableView {
    return 2;
}

- (NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}

- (UITableViewCell*) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        NSString* cellName = @"UserMainViewUserInfoTableViewCell";
        
        UserMainViewUserInfoTableViewCell* cell = [_tableView dequeueReusableCellWithIdentifier:cellName];
        
        if (cell == nil) {
            cell = [[UserMainViewUserInfoTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellName];
        }
        
        if (_userInfoDataModel) {
            [cell setUserMainViewUserInfoTableViewCellSex:_userInfoDataModel.sex];
            cell.userNickNameLabel.text = _userInfoDataModel.nickName;
            if (![_userInfoDataModel.introduction isEqualToString:@""]) {
                cell.userIntroductionLanel.text = _userInfoDataModel.introduction;
            } else {
                cell.userIntroductionLanel.text = @"这个人比较懒，还没有简介。";
            }
            cell.userIconURLString = _userInfoDataModel.icon;
            cell.userFansString = _userInfoDataModel.fans;
            cell.userFolloweeString = _userInfoDataModel.followee;
            cell.userNotesNumberString = _userInfoDataModel.notesNumber;
            
            [cell setUserInfoWithData];
        } else {
            [cell setUserMainViewUserInfoTableViewCellSex:0];
            [cell setUserMainViewUserInfoTableViewCellSex:0];
            cell.userNickNameLabel.text = @" 游客";
            cell.userIntroductionLanel.text = @"请先登陆/注册";
            cell.userIconURLString = @"";
            cell.userFansString = @"0";
            cell.userFolloweeString = @"0";
            cell.userNotesNumberString = @"0";
            
            [cell setUserInfoWithData];
        }
        return cell;
    } else {
        NSString* cellName = @"cellName";
        
        UITableViewCell* cell = [_tableView dequeueReusableCellWithIdentifier:cellName];
        
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellName];
        }
        
        cell.textLabel.text = @"退出登陆";
        cell.textLabel.textColor = [UIColor redColor];
        
        return cell;
    }
}

// 设置tableView行间距
- (UIView*) tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    UIView* view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, KSCREEN_WIDTH, 0)];
    return view;
}

- (CGFloat) tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 0;
}

// 刷新视图
- (void) reloadTableView {
    [_tableView reloadData];
}

#pragma mark - 点击事件
- (void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [_tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    if (indexPath.section == 0) {
        if (_userInfoDataModel == nil) {
            [[NSNotificationCenter defaultCenter] postNotificationName:messageOfToLogin object:nil];
        }
    } else if (indexPath.section == 1) {
        [[NSNotificationCenter defaultCenter] postNotificationName:messageOfExitLogin object:nil];
    }
}

@end
