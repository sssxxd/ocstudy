//
//  SceneDelegate.m
//  Love Nature-2.0
//
//  Created by 孙旭东 on 2023/1/15.
//

#import "SceneDelegate.h"

// 引入各视图控制器
#import "UserMainViewController.h"
#import "HomeViewController.h"
#import "ShareViewController.h"

@interface SceneDelegate ()
@property (nonatomic, strong) NSMutableArray* navViewControllerArray;

@property (nonatomic, strong) UITabBarController* tabBarController;
@end

@implementation SceneDelegate


- (void)scene:(UIScene *)scene willConnectToSession:(UISceneSession *)session options:(UISceneConnectionOptions *)connectionOptions {
    // Use this method to optionally configure and attach the UIWindow `window` to the provided UIWindowScene `scene`.
    // If using a storyboard, the `window` property will automatically be initialized and attached to the scene.
    // This delegate does not imply the connecting scene or session are new (see `application:configurationForConnectingSceneSession` instead).
    
    self.navViewControllerArray = [NSMutableArray array];
    
    [self createHomeViewController];
    [self createShareViewController];
    [self createUserMainViewController];
    
    self.tabBarController = [[UITabBarController alloc] init];
    _tabBarController.viewControllers = _navViewControllerArray;
    
    self.window = [[UIWindow alloc] initWithWindowScene:(UIWindowScene*)scene];
    self.window.rootViewController = _tabBarController;
    
    [self.window makeKeyAndVisible];
}


- (void)sceneDidDisconnect:(UIScene *)scene {
    // Called as the scene is being released by the system.
    // This occurs shortly after the scene enters the background, or when its session is discarded.
    // Release any resources associated with this scene that can be re-created the next time the scene connects.
    // The scene may re-connect later, as its session was not necessarily discarded (see `application:didDiscardSceneSessions` instead).
}


- (void)sceneDidBecomeActive:(UIScene *)scene {
    // Called when the scene has moved from an inactive state to an active state.
    // Use this method to restart any tasks that were paused (or not yet started) when the scene was inactive.
}


- (void)sceneWillResignActive:(UIScene *)scene {
    // Called when the scene will move from an active state to an inactive state.
    // This may occur due to temporary interruptions (ex. an incoming phone call).
}


- (void)sceneWillEnterForeground:(UIScene *)scene {
    // Called as the scene transitions from the background to the foreground.
    // Use this method to undo the changes made on entering the background.
}


- (void)sceneDidEnterBackground:(UIScene *)scene {
    // Called as the scene transitions from the foreground to the background.
    // Use this method to save data, release shared resources, and store enough scene-specific state information
    // to restore the scene back to its current state.
}

#pragma mark - 创建开机动画
- (void) setUPLaunch {
    UIView* launchView = [[UIView alloc] initWithFrame:[UIScreen mainScreen].bounds];
    
    // logo
    UIImageView* AppLogo = [[UIImageView alloc] initWithImage:[UIImage imageNamed:<#(nonnull NSString *)#>]];
}

#pragma mark - 创建视图控制器
- (void) createUserMainViewController {
    UserMainViewController* viewController = [[UserMainViewController alloc] init];
    
    UINavigationController* nav = [[UINavigationController alloc] initWithRootViewController:viewController];
    
    UITabBarItem* item = [[UITabBarItem alloc] initWithTitle:@"我的" image:[UIImage imageNamed:@"wode.png"] tag:101];
    
    nav.tabBarItem = item;
    [_navViewControllerArray addObject:nav];
}

- (void) createHomeViewController {
    HomeViewController* viewController = [[HomeViewController alloc] init];
    
    UINavigationController* nav = [[UINavigationController alloc] initWithRootViewController:viewController];
    
    UITabBarItem* item = [[UITabBarItem alloc] initWithTitle:@"首页" image:[UIImage imageNamed:@"shouye.png"] tag:101];
    
    nav.tabBarItem = item;
    [_navViewControllerArray addObject:nav];
}

- (void) createShareViewController {
    ShareViewController* viewController = [[ShareViewController alloc] init];
    
    UINavigationController* nav = [[UINavigationController alloc] initWithRootViewController:viewController];
    
    UITabBarItem* item = [[UITabBarItem alloc] initWithTitle:@"分享" image:[UIImage imageNamed:@"pengyouquan.png"] tag:101];
    
    nav.tabBarItem = item;
    [_navViewControllerArray addObject:nav];
}



@end
