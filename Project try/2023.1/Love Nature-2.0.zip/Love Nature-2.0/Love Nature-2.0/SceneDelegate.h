//
//  SceneDelegate.h
//  Love Nature-2.0
//
//  Created by 孙旭东 on 2023/1/15.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

