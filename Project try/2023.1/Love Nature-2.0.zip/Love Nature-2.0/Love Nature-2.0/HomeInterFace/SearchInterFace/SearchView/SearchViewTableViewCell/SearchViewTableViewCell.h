//
//  SearchViewTableViewCell.h
//  Love Nature-2.0
//
//  Created by 孙旭东 on 2023/2/6.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface SearchViewTableViewCell : UITableViewCell
@property (nonatomic, copy) NSString* imageString;
@property (nonatomic, strong) UILabel* nameLabel;
@end

NS_ASSUME_NONNULL_END
