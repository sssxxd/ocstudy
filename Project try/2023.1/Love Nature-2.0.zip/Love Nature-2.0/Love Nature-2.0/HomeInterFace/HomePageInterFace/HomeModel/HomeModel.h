//
//  HomeModel.h
//  Love Nature-2.0
//
//  Created by 孙旭东 on 2023/2/6.
//

#import "JSONModel.h"

NS_ASSUME_NONNULL_BEGIN

@protocol KeywordListDataModel <NSObject>
@end

@interface KeywordListDataModel : JSONModel
@property (nonatomic, copy) NSString* name;
@property (nonatomic, copy) NSString* image;
@end

@interface KeywordListModel : JSONModel
@property (nonatomic, copy) NSArray<KeywordListDataModel>* data;
@property (nonatomic, copy) NSString* code;
@property (nonatomic, copy) NSString* msg;
@property (nonatomic, strong) NSError* err;
@end

@interface HomeModel : NSObject
@property (nonatomic, strong) KeywordListModel* keywordListModel;
@end

NS_ASSUME_NONNULL_END
