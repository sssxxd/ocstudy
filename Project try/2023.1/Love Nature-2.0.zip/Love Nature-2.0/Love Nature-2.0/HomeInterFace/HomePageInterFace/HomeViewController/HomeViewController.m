//
//  HomeViewController.m
//  Love Nature-2.0
//
//  Created by 孙旭东 on 2023/2/6.
//

#import "HomeViewController.h"

// 引入视图控制器
#import "SearchViewController.h"

// 引入视图类和模型类
#import "HomeView.h"
#import "HomeModel.h"

// 引入工具类
#import "LNManager.h"

@interface HomeViewController ()
@property (nonatomic, strong) HomeView* homeView;
@property (nonatomic, strong) HomeModel* homeModel;
@end

@implementation HomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self initHomeView];
    [self initHomeModel];
    
    [self craeteSearchBar];
    [self createNavigationBarAppearance];
}

// 初始化模组
- (void) initHomeModel {
    self.homeModel = [[HomeModel alloc] init];
    
    
}

// 初始化视图
- (void) initHomeView {
    self.homeView = [[HomeView alloc] initWithFrame:self.view.bounds];
    self.homeView.backgroundColor = [UIColor whiteColor];
    
//    [self.homeView.photographButton addTarget:self action:@selector(pressPhotographButton) forControlEvents:UIControlEventTouchUpInside];
    
    [self.view addSubview:self.homeView];
}

// 设置NavigationBar
- (void) createNavigationBarAppearance {
    UINavigationBarAppearance* appearance = [[UINavigationBarAppearance alloc] init];
    appearance.backgroundColor = [UIColor greenColor];
    appearance.shadowImage = [UIImage new];
    appearance.shadowColor = nil;
    
    self.title = @"首页";
//    self.navigationController.title = nil;
    
//    [appearance setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor whiteColor], NSFontAttributeName:[UIFont systemFontOfSize:18]}];
    
    self.navigationController.navigationBar.standardAppearance = appearance;
    self.navigationController.navigationBar.scrollEdgeAppearance = appearance;
}

#pragma mark - 搜索
// 搜索栏
- (void) craeteSearchBar {
    UISearchBar* searchBar = [[UISearchBar alloc] init];
    searchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(0, 90, 390, 40)];
    searchBar.showsCancelButton = YES;
    searchBar.placeholder = @"搜索";
    searchBar.showsCancelButton = NO;
    searchBar.delegate = self;
    searchBar.keyboardType = UIKeyboardTypeDefault;
    
    self.navigationItem.titleView = searchBar;
}

- (void) searchBarSearchButtonClicked:(UISearchBar *)searchBar {
    [[LNManager shareLNManager] searchKeywork:searchBar.text succeedBlock:^(KeywordListModel * _Nonnull keywordListModel) {
        
        self.homeModel.keywordListModel = keywordListModel;

        dispatch_async(dispatch_get_main_queue(), ^{
            [self createSearchViewController];
        });
    } errorBlock:^(NSError * _Nonnull error) {
        NSLog(@"searchKeyList error");
    }];
}

- (void) createSearchViewController {
    SearchViewController* viewController = [[SearchViewController alloc] init];
    
    viewController.keywordListModel = _homeModel.keywordListModel;
    
    [self.navigationController pushViewController:viewController animated:YES];
}

@end
