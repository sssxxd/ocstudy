//
//  HomeView.m
//  Love Nature-2.0
//
//  Created by 孙旭东 on 2023/2/6.
//

#import "HomeView.h"

// 引入第三方库
#import "Masonry.h"

@implementation HomeView

- (instancetype) initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        self.backgroundColor = [UIColor whiteColor];
        [self createPhotographbutton];
    }
    return self;
}

- (void) createPhotographbutton {
    self.photographButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [_photographButton setImage:[UIImage imageNamed:@"photograph.jpeg"] forState:UIControlStateNormal];
    _photographButton.layer.cornerRadius = 10;
    _photographButton.layer.masksToBounds = YES;
    
    [self addSubview:_photographButton];
    
    [_photographButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_offset(110);
        make.left.mas_offset(20);
        make.right.mas_offset(-20);
        make.height.mas_offset(300);
    }];
}


@end
