//
//  SearchResultModel.m
//  Love Nature-2.0
//
//  Created by 孙旭东 on 2023/2/6.
//

#import "SearchResultModel.h"

@implementation SearchResultDataModel

+ (BOOL) propertyIsOptional:(NSString *)propertyName {
    return YES;
}

@end

@implementation SearchResultModel

+ (BOOL) propertyIsOptional:(NSString *)propertyName {
    return YES;
}

@end
