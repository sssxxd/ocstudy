//
//  UserLoginModel.m
//  Love Nature-2.0
//
//  Created by 孙旭东 on 2023/2/1.
//

#import "UserLoginModel.h"

@implementation UserEnrollModel

+ (BOOL) propertyIsOptional:(NSString *)propertyName {
    return YES;
}

@end

@implementation UserLoginDataModel

+ (BOOL) propertyIsOptional:(NSString *)propertyName {
    return YES;
}

@end

@implementation UserLoginModel

+ (BOOL) propertyIsOptional:(NSString *)propertyName {
    return YES;
}

@end
