//
//  TitleViewController.m
//  Find
//
//  Created by 孙旭东 on 2023/4/13.
//

#import "TitleViewController.h"

// 引入视图类
#import "TitleView.h"

@interface TitleViewController ()
@property (nonatomic, strong) TitleView* titlleView;
@end

@implementation TitleViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

#pragma mark - 懒加载
- (TitleView *)titlleView {
    if (_titlleView == nil) {
        self.titlleView = [[TitleView alloc] initWithFrame:self.view.frame];
    }
    return _titlleView;
}

@end
