//
//  CalassificationTableViewCell.h
//  Find
//
//  Created by 孙旭东 on 2023/3/29.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CalassificationTableViewCell : UITableViewCell

@property (nonatomic, copy) NSString* overButtonTitleString;

@end

NS_ASSUME_NONNULL_END
