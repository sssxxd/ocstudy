//
//  SearchModel.m
//  Find
//
//  Created by 孙旭东 on 2023/3/29.
//

#import "SearchModel.h"

@implementation KeywordListDataModel

+ (BOOL) propertyIsOptional:(NSString *)propertyName {
    return YES;
}

@end

@implementation KeywordListModel

+ (BOOL) propertyIsOptional:(NSString *)propertyName {
    return YES;
}

@end

@implementation SearchShareDataAuthorModel

+ (BOOL) propertyIsOptional:(NSString *)propertyName {
    return YES;
}

@end

@implementation SearchShareDataModel

+ (BOOL) propertyIsOptional:(NSString *)propertyName {
    return YES;
}

@end

@implementation SearchShareModel

+ (BOOL) propertyIsOptional:(NSString *)propertyName {
    return YES;
}

@end

@implementation SearchModel

+ (BOOL) propertyIsOptional:(NSString *)propertyName {
    return YES;
}

@end
