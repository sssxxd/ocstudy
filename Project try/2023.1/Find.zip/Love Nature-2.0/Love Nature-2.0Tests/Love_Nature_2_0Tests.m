//
//  Love_Nature_2_0Tests.m
//  Love Nature-2.0Tests
//
//  Created by 孙旭东 on 2023/1/15.
//

#import <XCTest/XCTest.h>

@interface Love_Nature_2_0Tests : XCTestCase

@end

@implementation Love_Nature_2_0Tests

- (void)setUp {
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
}

- (void)testExample {
    // This is an example of a functional test case.
    // Use XCTAssert and related functions to verify your tests produce the correct results.
}

- (void)testPerformanceExample {
    // This is an example of a performance test case.
    [self measureBlock:^{
        // Put the code you want to measure the time of here.
    }];
}

@end
